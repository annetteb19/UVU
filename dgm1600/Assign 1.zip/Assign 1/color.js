/*jslint devel: true */

var firstName, lastName, favColor;

firstName = prompt('enter your first name ');
lastName = prompt('enter your last name');
favColor = prompt('What\'s your favorite color?');


alert(firstName + ' ' + lastName + ' favorite color is ' + favColor);